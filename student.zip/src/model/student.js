const mongoose = require ('mongoose');
const studentSchema = mongoose.Schema({
    full_name:{
        type:String,
        required:true,
        // min:4,
        // max:20
    },
    age:{
        type:Number,
        required:true,
        // min:18,
        // max:40
    },
    sex:{
        type: String,
        required:true,
        // enum:['male', 'female']
    },
    final_score:{
        type:Number,
        required:true,
        // min:0,
        // max:100   
    },
});

const studentModel = mongoose.model('studentModel', studentSchema);
module.exports = studentModel;